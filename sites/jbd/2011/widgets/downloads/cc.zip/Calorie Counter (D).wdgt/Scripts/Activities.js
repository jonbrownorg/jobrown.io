function popupChanged(elem)				{					var chosenOption = elem.value;    			document.getElementById("popupMenuText").innerText = chosenOption;}

function popupChanged2(elem)				{					var chosenOption = elem.value;    			document.getElementById("popupMenuText2").innerText = chosenOption;}

function popupChanged3(elem)

		{					var chosenOption = elem.value;    			document.getElementById("popupMenuText3").innerText = chosenOption;}

function popupChanged4(elem)

		{					var chosenOption = elem.value;    			document.getElementById("popupMenuText4").innerText = chosenOption;}


function calcDCN (intWeight,intFeet,intInches,intAge,strGender,fltActivity,fitDist,fitTime) {

	// Gets Rate of Metabolism (BMR)
		// Step One: WeightSex
	var fltWM = intWeight * 6.2;
	var fltWW = intWeight * 4.4;
	
		// Step Two: Height, HeightSex
	var intHeight = intFeet * 12 + parseInt(intInches);
	var fltHM = intHeight * 12.7;
	var fltHW = intHeight * 4.7;
	
		// Step Three: AgeSex
	var fltAM = intAge * 6.8;
	var fltAW = intAge * 4.7;

	
		// Calculate: Basal Metabolic Rate
	var fltBMR;
	if (strGender == "male") {
		 fltBMR = ((fltWM + fltHM) - fltAM);
	} else {
		 fltBMR = ((fltWW + fltHW) - fltAW);
	}
	
	//  Gets Calories for Physical Activity, 
	//  Energy for Digestion and Absorption, 
	//  and Total Energy Needs               
	var fltCPA = fltBMR * fltActivity * fitDist * fitTime;
	var fltEDA = (fltBMR + fltCPA) * 0.001;
	var fltTEN = fltBMR + fltCPA + fltEDA * 0.01;
	
	// Write the result to the text box
	document.getElementById("result").innerText  = parseInt(fltCPA);
	
}

var myWeight;
var myDistance;

function stopSubmit() { 
return false; 
}
function ClearForm1(form){

    form.myWeight.value = "";
    form.myDistance.value = "";
    form.Fdiff.value = "";

   
    
}


function HowMany(form)
{
  var difference;
  difference = (myDistance * myWeight) * .653;
  document.getElementById("ok").innerText = difference;
  
   if (difference < 100) {
   document.getElementById("comment").innerText="You better get going! Practice Practice Practice";
   }
   if (difference >  101 && difference < 200) {
    document.getElementById("comment").innerText="Good Job! Nice run, try harder next time.";
   }
   if (difference >  201 && difference < 300) {
    document.getElementById("comment").innerText="Wow but you should keep trying for 300.";
   }
   if (difference >  301 && difference < 500) {
    document.getElementById("comment").innerText="Great work! Keep pushing yourself harder";
   }
   if (difference >  501 && difference < 700) {
    document.getElementById("comment").innerText="Excellent! Keep running and working hard!";
   }
   if (difference > 701) {
    document.getElementById("comment").innerText="Take a break have a meal at Mc Donalds!";  
   }
    
}

function SetMyWeight(weight)
{
  myWeight = weight.value;
}

function SetmyDistance(dis)
{
  myDistance = dis.value;
}

function ClearForm(form){

    form.myWeight.value = "";
    form.myDistance.value = "";
    form.Fdiff.value = "";
    form.comment.value = "";

}
function stopSubmit() { 
return false; 
}
function ClearForm(form){

    form.strGender.value = "Gender";
    form.fltActivity.value = "Lifestyle";
    form.intWeight.value = "";
    form.intAge.value = "";
    form.intFeet.value = "";
    form.intInches.value = "";
    form.fitDist.value = "";
    form.fitTime.value = "";
    form.Result.value = "";
    div.popupMenuText = "";
    document.getElementById("result").innerText = "";


   
    
}
