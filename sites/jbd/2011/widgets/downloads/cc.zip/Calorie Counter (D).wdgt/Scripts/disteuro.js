var euroWeight;
var euroDistance;

function stopSubmit() { 
return false; 
}
function ClearForm2(form){

    form.euroWeight.value = "";
    form.euroDistance.value = "";    
}


function HowMany1(form)
{
  var eurodifference;
  eurodifference = ((euroDistance / 1.61) * (euroWeight * 2.2)) * .653;
  document.getElementById("eurodisplay").innerText = custRound2(eurodifference,10);
  
function custRound2(x,places) {
  return (Math.round(x*Math.pow(10,places)))/Math.pow(10,places)
   }
}

function SetMyWeight(weight1)
{
  euroWeight = weight1.value;
}

function SetmyDistance(dis1)
{
  euroDistance = dis1.value;
}