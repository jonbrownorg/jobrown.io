function stopSubmit() { 
return false; 
}
function ClearForm1(form){

    form.myWeight.value = "";
    form.myDistance.value = "";
    form.Fdiff.value = "";

   
    
}
function mod(div,base) {
return Math.round(div - (Math.floor(div/base)*base));
}
function calcBmi() {
var w = document.bmi.weight.value * 1;
var HeightFeetInt = document.bmi.htf.value * 1;
var HeightInchesInt = document.bmi.hti.value * 1;
HeightFeetConvert = HeightFeetInt * 12;
h = HeightFeetConvert + HeightInchesInt;
displaybmi = (Math.round((w * 703) / (h * h)));
var rvalue = true;
if ( (w <= 35) || (w >= 500)  || (h <= 48) || (h >= 120) ) {
rvalue = false;
}
if (rvalue) {
if (HeightInchesInt > 11) {
reminderinches = mod(HeightInchesInt,12);
document.bmi.hti.value = reminderinches;
document.bmi.htf.value = HeightFeetInt + 
((HeightInchesInt - reminderinches)/12);
document.bmi.answer.value = displaybmi;
}
if (displaybmi <19) 
document.getElementById("comment").innerText = "Underweight";
if (displaybmi >=19 && displaybmi <=25) 
document.getElementById("comment").innerText = "Desirable";
if (displaybmi >=26 && displaybmi <=29) 
document.getElementById("comment").innerText = "Heath Risk";
if (displaybmi >=30 && displaybmi <=40) 
document.getElementById("comment").innerText = "Obese";
if (displaybmi >40) 
document.getElementById("comment").innerText = "Very obese";
document.getElementById("answer").innerText = displaybmi; }
return rvalue;
}