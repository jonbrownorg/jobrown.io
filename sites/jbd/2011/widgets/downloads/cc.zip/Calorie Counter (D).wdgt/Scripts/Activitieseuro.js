function popupChanged(elem)				{					var chosenOption = elem.value;    			document.getElementById("popupMenuText").innerText = chosenOption;}

function popupChanged2(elem)				{					var chosenOption = elem.value;    			document.getElementById("popupMenuText2").innerText = chosenOption;}

function popupChanged3(elem)

		{					var chosenOption = elem.value;    			document.getElementById("popupMenuText3").innerText = chosenOption;}

function popupChanged4(elem)

		{					var chosenOption = elem.value;    			document.getElementById("popupMenuText4").innerText = chosenOption;}


function calcDCN2 (intWeight2,intFeet2,intAge2,strGender2,fltActivity2,fitDist2,fitTime2) {

	// Gets Rate of Metabolism (BMR)
		// Step One: WeightSex
	var fltWM2 = intWeight2 * 6.2 * 2.2;
	var fltWW2 = intWeight2 * 4.4 * 2.2;
	
		// Step Two: Height, HeightSex
	var intHeight2 = intFeet2 / 30.48;
	var fltHM2 = intHeight2 * 200.7;
	var fltHW2 = intHeight2 * 202.7;
	
		// Step Three: AgeSex
	var fltAM2 = intAge2 * 6.8;
	var fltAW2 = intAge2 * 4.7;

	
		// Calculate: Basal Metabolic Rate
	var fltBMR2;
	if (strGender2 == "male") {
		 fltBMR2 = ((fltWM2 + fltHM2) - fltAM2);
	} else {
		 fltBMR2 = ((fltWW2 + fltHW2) - fltAW2);
	}
	
	//  Gets Calories for Physical Activity, 
	//  Energy for Digestion and Absorption, 
	//  and Total Energy Needs               
	var fltCPA2 = fltBMR2 * fltActivity2 * fitDist2 * fitTime2;
	var fltEDA2 = (fltBMR2 + fltCPA2) * 0.001;
	var fltTEN2 = fltBMR2 + fltCPA2 + fltEDA2 * 0.01;
	
	// Write the result to the text box
	document.getElementById("result").innerText  = parseInt(fltCPA2);
	
}
var actWeight2;
var actDistance2;

function stopSubmit() { 
return false; 
}

function SetactWeight2(weight)
{
  actWeight2 = weight.value;
}

function SetactDistance2(dis)
{
  actDistance2 = dis.value;
}

function ClearForm2(form){

    form.actWeight2.value = "";
    form.actDistance2.value = "";

}

function stopSubmit() { 
return false; 
}
function ClearForm21(form){

    form.strGender2.value = "Gender";
    form.fltActivity2.value = "Lifestyle";
    form.intWeight2.value = "";
    form.intAge2.value = "";
    form.intFeet2.value = "";
    form.intInches2.value = "";
    form.fitDist2.value = "";
    form.fitTime2.value = "";
    form.Result2.value = "";
    div.popupMenuText = "";
    document.getElementById("result").innerText = "";


   
    
}


