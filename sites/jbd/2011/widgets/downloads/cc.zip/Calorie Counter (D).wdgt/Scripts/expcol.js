function toggleList(e){
        element = document.getElementById(e).style;
        element.display == 'none' ? element.display = 'block' : 
element.display='none';
}