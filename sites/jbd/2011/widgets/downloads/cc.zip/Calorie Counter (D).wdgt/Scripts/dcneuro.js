


// The main calculation function
var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};
function mousemove (event)
{
    if (!flipShown)
    {
        if (animation.timer != null)
        {
            clearInterval (animation.timer);
            animation.timer  = null;
        }
                
        var starttime = (new Date).getTime() - 13;
                
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById ('act');
        animation.timer = setInterval ("animate();", 13);
        animation.from = animation.now;
        animation.to = 1.0;
        animate();
        flipShown = true;
    }
}
function mouseexit (event)
{
    if (flipShown)
    {
        // fade in the info button
        if (animation.timer != null)
        {
            clearInterval (animation.timer);
            animation.timer  = null;
        }
                
        var starttime = (new Date).getTime() - 13;
                
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById ('act');
        animation.timer = setInterval ("animate();", 13);
        animation.from = animation.now;
        animation.to = 0.0;
        animate();
        flipShown = false;
    }
}
function animate()
{
    var T;
    var ease;
    var time = (new Date).getTime();
                
        
    T = limit_3(time-animation.starttime, 0, animation.duration);
        
    if (T >= animation.duration)
    {
        clearInterval (animation.timer);
        animation.timer = null;
        animation.now = animation.to;
    }
    else
    {
        ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
        animation.now = computeNextFloat (animation.from, animation.to, ease);
    }
        
    animation.firstElement.style.opacity = animation.now;
}
function limit_3 (a, b, c)
{
    return a < b ? b : (a > c ? c : a);
}
function computeNextFloat (from, to, ease)
{
    return from + (to - from) * ease;
}
function enterflip(event)
{
    document.getElementById('act').style.display = 'block';
}
function exitflip(event)
{
    document.getElementById('act').style.display = 'none';
}
function showActivities()
{
    var front = document.getElementById("front");
    var activities = document.getElementById("activities");
        
    if (window.widget)
        widget.prepareForTransition("ToActivities");
                
    front.style.display="none";
    activities.style.display="block";
        
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);  
}
function hideActivities()
{
    var front = document.getElementById("front");
    var activities = document.getElementById("activities");
        
    if (window.widget)
        widget.prepareForTransition("ToFront");
                
    activities.style.display="none";
    front.style.display="block";
        
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);
}
 
// The main calculation function
var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};
function mousemove (event)
{
    if (!flipShown)
    {
        if (animation.timer != null)
        {
            clearInterval (animation.timer);
            animation.timer  = null;
        }
                
        var starttime = (new Date).getTime() - 13;
                
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById ('show');
        animation.timer = setInterval ("animate();", 13);
        animation.from = animation.now;
        animation.to = 1.0;
        animate();
        flipShown = true;
    }
}
function mouseexit (event)
{
    if (flipShown)
    {
        // fade in the info button
        if (animation.timer != null)
        {
            clearInterval (animation.timer);
            animation.timer  = null;
        }
                
        var starttime = (new Date).getTime() - 13;
                
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById ('show');
        animation.timer = setInterval ("animate();", 13);
        animation.from = animation.now;
        animation.to = 0.0;
        animate();
        flipShown = false;
    }
}
function animate()
{
    var T;
    var ease;
    var time = (new Date).getTime();
                
        
    T = limit_3(time-animation.starttime, 0, animation.duration);
        
    if (T >= animation.duration)
    {
        clearInterval (animation.timer);
        animation.timer = null;
        animation.now = animation.to;
    }
    else
    {
        ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
        animation.now = computeNextFloat (animation.from, animation.to, ease);
    }
        
    animation.firstElement.style.opacity = animation.now;
}
function limit_3 (a, b, c)
{
    return a < b ? b : (a > c ? c : a);
}
function computeNextFloat (from, to, ease)
{
    return from + (to - from) * ease;
}
function enterflip(event)
{
    document.getElementById('showrollie').style.display = 'block';
}
function exitflip(event)
{
    document.getElementById('showrollie').style.display = 'none';
}
function showRun()
{
    var front = document.getElementById("front");
    var Run = document.getElementById("run");
        
    if (window.widget)
        widget.prepareForTransition("ToRun");
                
    front.style.display="none";
    Run.style.display="block";
        
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);  
}
function hideRun()
{
    var front = document.getElementById("front");
    var Run = document.getElementById("run");
        
    if (window.widget)
        widget.prepareForTransition("ToFront");
                
    Run.style.display="none";
    front.style.display="block";
        
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);
}

 
// The main calculation function
var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};
function mousemove (event)
{
    if (!flipShown)
    {
        if (animation.timer != null)
        {
            clearInterval (animation.timer);
            animation.timer  = null;
        }
                
        var starttime = (new Date).getTime() - 13;
                
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById ('flip');
        animation.timer = setInterval ("animate();", 13);
        animation.from = animation.now;
        animation.to = 1.0;
        animate();
        flipShown = true;
    }
}
function mouseexit (event)
{
    if (flipShown)
    {
        // fade in the info button
        if (animation.timer != null)
        {
            clearInterval (animation.timer);
            animation.timer  = null;
        }
                
        var starttime = (new Date).getTime() - 13;
                
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById ('flip');
        animation.timer = setInterval ("animate();", 13);
        animation.from = animation.now;
        animation.to = 0.0;
        animate();
        flipShown = false;
    }
}
function animate()
{
    var T;
    var ease;
    var time = (new Date).getTime();
                
        
    T = limit_3(time-animation.starttime, 0, animation.duration);
        
    if (T >= animation.duration)
    {
        clearInterval (animation.timer);
        animation.timer = null;
        animation.now = animation.to;
    }
    else
    {
        ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
        animation.now = computeNextFloat (animation.from, animation.to, ease);
    }
        
    animation.firstElement.style.opacity = animation.now;
}
function limit_3 (a, b, c)
{
    return a < b ? b : (a > c ? c : a);
}
function computeNextFloat (from, to, ease)
{
    return from + (to - from) * ease;
}
function enterflip(event)
{
    document.getElementById('fliprollie').style.display = 'block';
}
function exitflip(event)
{
    document.getElementById('fliprollie').style.display = 'none';
}
function showBack()
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");
        
    if (window.widget)
        widget.prepareForTransition("ToBack");
                
    front.style.display="none";
    back.style.display="block";
        
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);  
}
function hideBack()
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");
        
    if (window.widget)
        widget.prepareForTransition("ToFront");
                
    back.style.display="none";
    front.style.display="block";
        
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);
}
function popupChanged(elem)				{					var chosenOption = elem.value;    			document.getElementById("popupMenuText").innerText = chosenOption;}

function popupChanged2(elem)				{					var chosenOption = elem.value;    			document.getElementById("popupMenuText2").innerText = chosenOption;}

function popupChanged3(elem)

		{					var chosenOption = elem.value;    			document.getElementById("popupMenuText3").innerText = chosenOption;}

function popupChanged4(elem)

		{					var chosenOption = elem.value;    			document.getElementById("popupMenuText4").innerText = chosenOption;}


function calcDCN (intWeight,intFeet,intInches,intAge,strGender,fltActivity,fitDist,fitTime) {

	// Gets Rate of Metabolism (BMR)
		// Step One: WeightSex
	var fltWM = intWeight * 6.2 * 2.2;
	var fltWW = intWeight * 4.4 * 2.2;
	
		// Step Two: Height, HeightSex
	var intHeight = intFeet / 30;
	var fltHM = intHeight * 64.7;
	var fltHW = intHeight * 55.7;
	
		// Step Three: AgeSex
	var fltAM = intAge * 6.8;
	var fltAW = intAge * 4.7;

	
		// Calculate: Basal Metabolic Rate
	var fltBMR;
	if (strGender == "male") {
		 fltBMR = ((fltWM + fltHM) - fltAM);
	} else {
		 fltBMR = ((fltWW + fltHW) - fltAW);
	}
	
	//  Gets Calories for Physical Activity, 
	//  Energy for Digestion and Absorption, 
	//  and Total Energy Needs               
	var fltCPA = fltBMR * fltActivity * fitDist * fitTime;
	var fltEDA = (fltBMR + fltCPA) * 0.001;
	var fltTEN = fltBMR + fltCPA + fltEDA * 0.01;
	
	// Write the result to the text box
	document.getElementById("result").innerText  = parseInt(fltCPA);
	
}
