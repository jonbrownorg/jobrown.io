function button1Pressed(){
  swapDivs("front","behind","ToBack");
}

function stopSubmit() { 
return false; 
}

function noenter() {
  return !(window.event && window.event.keyCode == 13); }

var months = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
var days = new Array("images/sun.png","images/mon.png","images/tues.png","images/wed.png","images/thurs.png","images/fri.png","images/sat.png");
var mtend = new Array(31,28,31,30,31,30,31,31,30,31,30,31);
var opt = new Array("images/past.png","images/future.png");
function getDateInfo() {
var y = document.form.year.value;
var m = document.form.month.options[document.form.month.options.selectedIndex].value;
var d = document.form.day.options[document.form.day.options.selectedIndex].value;
var hlpr = mtend[m];
if (d < mtend[m] + 1) {
if (m == 1 && y % 4 == 0) { hlpr++; }
var c = new Date(y,m,d);
var dayOfWeek = c.getDay();
document.images.picture.src = days[dayOfWeek];
if(c.getTime() > new Date().getTime()) {
document.images.pictures.src = opt[1];
}
else {
document.images.pictures.src = opt[0];
   }
}
else {
alert("The date "+months[m]+" "+d+", "+y+" is invalid.\nCheck it again.");
   }
}
function setY() {
var y = new Date().getYear();
if (y < 2000) y += 1900;
document.form.year.value = y;
}

// The main calculation function
var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};
function mousemove (event)
{
    if (!flipShown)
    {
        if (animation.timer != null)
        {
            clearInterval (animation.timer);
            animation.timer  = null;
        }
                
        var starttime = (new Date).getTime() - 13;
                
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById ('flip');
        animation.timer = setInterval ("animate();", 13);
        animation.from = animation.now;
        animation.to = 1.0;
        animate();
        flipShown = true;
    }
}
function mouseexit (event)
{
    if (flipShown)
    {
        // fade in the info button
        if (animation.timer != null)
        {
            clearInterval (animation.timer);
            animation.timer  = null;
        }
                
        var starttime = (new Date).getTime() - 13;
                
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById ('flip');
        animation.timer = setInterval ("animate();", 13);
        animation.from = animation.now;
        animation.to = 0.0;
        animate();
        flipShown = false;
    }
}
function animate()
{
    var T;
    var ease;
    var time = (new Date).getTime();
                
        
    T = limit_3(time-animation.starttime, 0, animation.duration);
        
    if (T >= animation.duration)
    {
        clearInterval (animation.timer);
        animation.timer = null;
        animation.now = animation.to;
    }
    else
    {
        ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
        animation.now = computeNextFloat (animation.from, animation.to, ease);
    }
        
    animation.firstElement.style.opacity = animation.now;
}
function limit_3 (a, b, c)
{
    return a < b ? b : (a > c ? c : a);
}
function computeNextFloat (from, to, ease)
{
    return from + (to - from) * ease;
}
function enterflip(event)
{
    document.getElementById('fliprollie').style.display = 'block';
}
function exitflip(event)
{
    document.getElementById('fliprollie').style.display = 'none';
}
function showBack()
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");
        
    if (window.widget)
        widget.prepareForTransition("ToBack");
                
    front.style.display="none";
    back.style.display="block";
        
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);  
}
function hideBack()
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");
        
    if (window.widget)
        widget.prepareForTransition("ToFront");
                
    back.style.display="none";
    front.style.display="block";
        
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);
}

var currentVersion; 

function loaded() {  //called when the html document is loaded 
    currentVersion = getKeyValue("Info.plist", "CFBundleVersion"); 
    checkForUpdate(); 
} 

function checkForUpdate() { 
    req = new XMLHttpRequest(); 
    req.onreadystatechange = compareVersion; 
    req.open("GET", "http://www.jonbrown.org/timeversion.php", true); 
    req.setRequestHeader("Cache-Control", "no-cache"); 
    req.send(null); 
} 

function compareVersion() { 
  if (req.readyState == 4) { 
    if (req.status == 200) { 
        var serverVersion = req.responseText; 

        if ((currentVersion != serverVersion) && (serverVersion != null) && (serverVersion != "")) { 
            document.getElementById('updateMessage').style.display='block'; 
        } else { 
            document.getElementById('updateMessage').style.display='none'; 
        } 
    } 
  } 
} 

function getKeyValue(plist, key) { 
   var xml_http = new XMLHttpRequest(); 
   xml_http.open("GET", plist, false); 
   xml_http.send(null); 
    
   var xml = xml_http.responseXML; 
   var key_value = null; 
   var nodes = xml.getElementsByTagName("dict")[0].childNodes; 

   for (var i=0; i < nodes.length; i++) { 
      if (nodes[i].nodeType == 1 && nodes[i].tagName.toLowerCase() == "key" && nodes[i].firstChild.data == key) { 
         if (nodes[i+2].tagName.toLowerCase() != "array") { 
            key_value = nodes[i+2].firstChild.data; 
         } else { 
            key_value = new Array(); 
            var ar_nodes = nodes[i+2].childNodes; 
            for (var j=0; j < ar_nodes.length; j++) { 
               if (ar_nodes[j].nodeType == 1) key_value.push(ar_nodes[j].firstChild.data); 
            } 
         } 
          
         break; 
      } 
   } 
    
   return key_value; 
} 