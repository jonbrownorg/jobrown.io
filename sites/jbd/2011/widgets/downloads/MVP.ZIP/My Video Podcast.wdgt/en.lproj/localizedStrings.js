var localizedStrings = new Object;

localizedStrings["My Blog"] = "My Blog";
localizedStrings["New URL: "] = "New URL: ";
localizedStrings["Set"] = "Set";
localizedStrings["Feed URLs: "] = "Feed URLs: ";
localizedStrings["Reset"] = "Reset";
localizedStrings["Done"] = "Done";
