function fido (){
	document.getElementById('dogyear').innerHTML = document.getElementById('humanyears').value * 7 +" Yrs. Old";
	document.getElementById('1').innerHTML = "In Dog Years";
	document.getElementById('2').innerHTML = "You Are";

}