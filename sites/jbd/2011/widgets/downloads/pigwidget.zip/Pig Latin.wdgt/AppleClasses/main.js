function button1Pressed(){
  swapDivs("front","behind","ToBack");
}

function reset2(){
document.getElementById('area').style.display = "block";
document.getElementById('area').value = "";
document.getElementById('link').style.display = "none";
document.getElementById('container').style.display = "none";
document.getElementById('content').innerHTML = "";	
document.getElementById('typearea').innerHTML = "";
  calculateAndShowThumb(document.getElementById('typearea'));	
}


function reset(){
document.getElementById('area').style.display = "block";
document.getElementById('link').style.display = "none";
document.getElementById('container').style.display = "none";
document.getElementById('content').innerHTML = "";	

}
function refreshScrollbar(){

document.getElementById('typearea').style.top = '0px'; 
document.getElementById('content').style.top = '0px'; 
  calculateAndShowThumb(document.getElementById('typearea'));	

}
function toggleList5(){
        element = document.getElementById('container').style;
        element.display == 'block' ? element.display = 'none' : 
element.display='block';

}

function toggleList4(){
        element = document.getElementById('content').style;
        element.display == 'none' ? element.display = 'block' : 
element.display='none';

}
function toggleList3(){
        element = document.getElementById('link').style;
        element.display == 'block' ? element.display = 'none' : 
element.display='block';

}
function toggleList2(){
        element = document.getElementById('typearea').style;
        element.display == 'none' ? element.display = 'block' : 
element.display='none';

}

function toggleList(){
        element = document.getElementById('area').style;
        element.display == 'none' ? element.display = 'block' : 
element.display='none';
}
function typing(){
       document.getElementById('typearea').innerHTML = document.getElementById('area').value;
document.getElementById('content').style.top = '0px'; 
  calculateAndShowThumb(document.getElementById('typearea'));
}
function translate() {
  output = ""
  input = document.piglatin.input.value
  inputArray = new Array()
  inputArray = input.split(" ")
  punct = ".,?\"':;!"
  word = "";

  for (count=0; count<inputArray.length; count++){
    word = String(inputArray[count])
    endPunct = "";

    for (i=0; i<punct.length; i++) {
      if(word.charAt(word.length-1)==punct.charAt(i)) {
        endPunct = punct.charAt(i)
        word = word.substr(0,word.length-1)
      } 
    }

    firstLetter = word.substring(1,2)
      if(word.charAt(0)=="a" || word.charAt(0)=="A" || word.charAt(0)=="e" || word.charAt(0)=="E" || word.charAt(0)=="i" || word.charAt(0)=="I" || word.charAt(0)=="o" || word.charAt(0)=="O" || word.charAt(0)=="u" || word.charAt(0)=="U"){
        output += word+"way"+endPunct+" "
      } else if(word.charAt(1)=="a" || word.charAt(1)=="A" || word.charAt(1)=="e" || word.charAt(1)=="E" || word.charAt(1)=="i" || word.charAt(1)=="I" || word.charAt(1)=="o" || word.charAt(1)=="O" || word.charAt(1)=="u" || word.charAt(1)=="U") {
               start = word.substring(0,1)
               output+= word.substring(1,word.length)+start+"ay"+endPunct+" "
      } else if(word.charAt(2)=="a" || word.charAt(2)=="A" || word.charAt(2)=="e" || word.charAt(2)=="E" || word.charAt(2)=="i" || word.charAt(2)=="I" || word.charAt(2)=="o" || word.charAt(2)=="O" || word.charAt(2)=="u" || word.charAt(2)=="U") {
               start = word.substring(0,2)
               output+= word.substring(2,word.length)+start+"ay"+endPunct+" "
      } else if(word.charAt(3)=="a" || word.charAt(3)=="A" || word.charAt(3)=="e" || word.charAt(3)=="E" || word.charAt(3)=="i" || word.charAt(3)=="I" || word.charAt(3)=="o" || word.charAt(3)=="O" || word.charAt(3)=="u" || word.charAt(3)=="U") {
               start = word.substring(0,3)
               output+= word.substring(3,word.length)+start+"ay"+endPunct+" "
      } else {
         start = word.substring(0,1)
         output+= word.substring(1,word.length)+start+"ay"+endPunct+" "
      }
  document.getElementById('content').innerHTML = output
  calculateAndShowThumb(document.getElementById('content'));
  }
}


// The main calculation function
var flipShown = false;
var animation = {duration:0, starttime:0, to:1.0, now:0.0, from:0.0, firstElement:null, timer:null};
function mousemove (event)
{
    if (!flipShown)
    {
        if (animation.timer != null)
        {
            clearInterval (animation.timer);
            animation.timer  = null;
        }
                
        var starttime = (new Date).getTime() - 13;
                
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById ('flip');
        animation.timer = setInterval ("animate();", 13);
        animation.from = animation.now;
        animation.to = 1.0;
        animate();
        flipShown = true;
    }
}
function mouseexit (event)
{
    if (flipShown)
    {
        // fade in the info button
        if (animation.timer != null)
        {
            clearInterval (animation.timer);
            animation.timer  = null;
        }
                
        var starttime = (new Date).getTime() - 13;
                
        animation.duration = 500;
        animation.starttime = starttime;
        animation.firstElement = document.getElementById ('flip');
        animation.timer = setInterval ("animate();", 13);
        animation.from = animation.now;
        animation.to = 0.0;
        animate();
        flipShown = false;
    }
}
function animate()
{
    var T;
    var ease;
    var time = (new Date).getTime();
                
        
    T = limit_3(time-animation.starttime, 0, animation.duration);
        
    if (T >= animation.duration)
    {
        clearInterval (animation.timer);
        animation.timer = null;
        animation.now = animation.to;
    }
    else
    {
        ease = 0.5 - (0.5 * Math.cos(Math.PI * T / animation.duration));
        animation.now = computeNextFloat (animation.from, animation.to, ease);
    }
        
    animation.firstElement.style.opacity = animation.now;
}
function limit_3 (a, b, c)
{
    return a < b ? b : (a > c ? c : a);
}
function computeNextFloat (from, to, ease)
{
    return from + (to - from) * ease;
}
function enterflip(event)
{
    document.getElementById('fliprollie').style.display = 'block';
}
function exitflip(event)
{
    document.getElementById('fliprollie').style.display = 'none';
}
function showBack()
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");
        
    if (window.widget)
        widget.prepareForTransition("ToBack");
                
    front.style.display="none";
    back.style.display="block";
        
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);  
}
function hideBack()
{
    var front = document.getElementById("front");
    var back = document.getElementById("back");
        
    if (window.widget)
        widget.prepareForTransition("ToFront");
                
    back.style.display="none";
    front.style.display="block";
        
    if (window.widget)
        setTimeout ('widget.performTransition();', 0);
}

var currentVersion; 

function loaded() {  //called when the html document is loaded 
    currentVersion = getKeyValue("Info.plist", "CFBundleVersion"); 
    checkForUpdate(); 
  calculateAndShowThumb(document.getElementById('content'));
} 

function checkForUpdate() { 
    req = new XMLHttpRequest(); 
    req.onreadystatechange = compareVersion; 
    req.open("GET", "http://www.jonbrown.org/timeversion.php", true); 
    req.setRequestHeader("Cache-Control", "no-cache"); 
    req.send(null); 
} 

function compareVersion() { 
  if (req.readyState == 4) { 
    if (req.status == 200) { 
        var serverVersion = req.responseText; 

        if ((currentVersion != serverVersion) && (serverVersion != null) && (serverVersion != "")) { 
            document.getElementById('updateMessage').style.display='block'; 
        } else { 
            document.getElementById('updateMessage').style.display='none'; 
        } 
    } 
  } 
} 

function getKeyValue(plist, key) { 
   var xml_http = new XMLHttpRequest(); 
   xml_http.open("GET", plist, false); 
   xml_http.send(null); 
    
   var xml = xml_http.responseXML; 
   var key_value = null; 
   var nodes = xml.getElementsByTagName("dict")[0].childNodes; 

   for (var i=0; i < nodes.length; i++) { 
      if (nodes[i].nodeType == 1 && nodes[i].tagName.toLowerCase() == "key" && nodes[i].firstChild.data == key) { 
         if (nodes[i+2].tagName.toLowerCase() != "array") { 
            key_value = nodes[i+2].firstChild.data; 
         } else { 
            key_value = new Array(); 
            var ar_nodes = nodes[i+2].childNodes; 
            for (var j=0; j < ar_nodes.length; j++) { 
               if (ar_nodes[j].nodeType == 1) key_value.push(ar_nodes[j].firstChild.data); 
            } 
         } 
          
         break; 
      } 
   } 
    
   return key_value; 
} 





function saveText()
{
	var text = document.getElementById('content').innerHTML;	
	text = text.replace(/\<BR\>/gi, '\r');
	text = text.replace(/\'/g, '');

	var timestamp = text.substr(0,5);
	
	// Actually save it.
	var saving = widget.system("/bin/echo '" + text + "' > ~/Desktop/Pig_" + timestamp + ".txt", done);
}

function done()
{
document.getElementById('typearea').style.display='none'; 
}
