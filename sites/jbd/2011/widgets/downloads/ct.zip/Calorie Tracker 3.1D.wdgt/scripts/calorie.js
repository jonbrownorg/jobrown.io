function ajaxpage(url, containerid){
var page_request = false
if (window.XMLHttpRequest) // if Mozilla, Safari etc
page_request = new XMLHttpRequest()
else if (window.ActiveXObject){ // if IE
try {
page_request = new ActiveXObject("Msxml2.XMLHTTP")
} 
catch (e){
try{
page_request = new ActiveXObject("Microsoft.XMLHTTP")
}
catch (e){}
}
}
else
return false
page_request.onreadystatechange=function(){
loadpage(page_request, containerid)
}
page_request.open('GET', url, true)
page_request.send(null)
}

function loadpage(page_request, containerid){
if (page_request.readyState == 4 && (page_request.status==200 || window.location.href.indexOf("http")==-1))
document.getElementById(containerid).innerHTML=page_request.responseText
}

function loadobjs(){
if (!document.getElementById)
return
for (i=0; i<arguments.length; i++){
var file=arguments[i]
var fileref=""
if (loadedobjects.indexOf(file)==-1){ //Check to see if this object has not already been added to page before proceeding
if (file.indexOf(".js")!=-1){ //If object is a js file
fileref=document.createElement('script')
fileref.setAttribute("type","text/javascript");
fileref.setAttribute("src", file);
}
else if (file.indexOf(".css")!=-1){ //If object is a css file
fileref=document.createElement("link")
fileref.setAttribute("rel", "stylesheet");
fileref.setAttribute("type", "text/css");
fileref.setAttribute("href", file);
}
}
if (fileref!=""){
document.getElementsByTagName("head").item(0).appendChild(fileref)
loadedobjects+=file+" " //Remember this object as being already added to page
}
}
}
function ajaxcombo(selectobjID, loadarea){
var selectobj=document.getElementById? document.getElementById(selectobjID) : ""
if (selectobj!="" && selectobj.options[selectobj.selectedIndex].id!="")
ajaxpage(selectobj.options[selectobj.selectedIndex].id, loadarea)
}


/*
***	Functions for the Nav Buttons
***
*** These process the requests made by clicking the user interface buttons
*/
function loaded() 
{
	calculateAndShowThumb(document.getElementById('content'));
	calculateAndShowThumbs(document.getElementById('AddStuff'));
	document.getElementById('trackgraphon').style.display='block'; 
	document.getElementById('trackgraphoff').style.display='none'; 
}


function drawerout() 
{
	document.getElementById('drawerexpand').style.display = 'none';
	document.getElementById('boxHorizontalOnly').style.display = 'block';
	document.getElementById('drawercollapse').style.display = 'block';
	document.getElementById('indrawer').style.display = 'block';
}
function drawerin() 
{
	document.getElementById('drawerexpand').style.display = 'block';
	document.getElementById('boxHorizontalOnly').style.display = 'none';
	document.getElementById('drawercollapse').style.display = 'none';
	document.getElementById('indrawer').style.display = 'none';
}


function showeditmode() 
{
	runstatus();
	document.getElementById('graphon').style.display='block'; 
	document.getElementById('graphoff').style.display='none'; 
	document.getElementById('TheBarChtUpdt').style.display='none'; 
	document.getElementById('grid').style.display='block'; 
	document.getElementById('graphic').style.display='none'; 
	document.getElementById('graphview').style.display='none';
	document.getElementById('graphed').style.display = 'none';
	document.getElementById('data').style.display = 'none';
	document.getElementById('copy').style.display = 'block';
	document.getElementById('editon').style.display = 'none';
	document.getElementById('TheBarCht').style.display='none';
	document.getElementById('editoff').style.display = 'block';
	document.getElementById('trackgraphon').style.display = 'none';
	document.getElementById('trackgraphoff').style.display = 'none';
}

function hideeditmode() 
{
	runstatus();
	document.getElementById('graphon').style.display='block'; 
	document.getElementById('graphoff').style.display='none'; 
	document.getElementById('TheBarChtUpdt').style.display='none'; 
	document.getElementById('grid').style.display='block'; 
	document.getElementById('graphic').style.display='none'; 
	document.getElementById('graphview').style.display='none';
	document.getElementById('graphed').style.display = 'none';
	document.getElementById('data').style.display = 'block';
	document.getElementById('copy').style.display = 'none';
	document.getElementById('editon').style.display = 'block';
	document.getElementById('editoff').style.display = 'none';
	document.getElementById('TheBarCht').style.display='none';
	document.getElementById('trackgraphon').style.display = 'none';
	document.getElementById('trackgraphoff').style.display = 'none';
}
function showtrackgraphmode() 
{
	runstatus();
	document.getElementById('trackgraphon').style.display='none'; 
	document.getElementById('trackgraphoff').style.display='block'; 
	document.getElementById('TheBarCht').style.display='block';
	document.getElementById('content').style.display='none'; 
	document.getElementById('welcome').style.display='none'; 
	document.getElementById('graphview').style.display='block'; 
	document.getElementById('TheBarChtUpdt').style.display='block'; 
}
function hidetrackgraphmode() 
{
	runstatus();
	document.getElementById('trackgraphon').style.display='block'; 
	document.getElementById('trackgraphoff').style.display='none'; 
	document.getElementById('content').style.display='block'; 
	document.getElementById('welcome').style.display='block'; 
	document.getElementById('TheBarCht').style.display='none'; 
	document.getElementById('graphview').style.display='none'; 
	document.getElementById('TheBarChtUpdt').style.display='none'; 
}
function showgraphmode() 
{
	runstatus();
	document.getElementById('editon').style.display='block'; 
	document.getElementById('editoff').style.display='none'; 
	document.getElementById('graphic').style.display='block'; 
	document.getElementById('TheBarChtUpdt').style.display='none'; 
	document.getElementById('grid').style.display='none'; 
	document.getElementById('graphview').style.display='none';
	document.getElementById('graphoff').style.display = 'block';
	document.getElementById('graphon').style.display = 'none';
	document.getElementById('graphed').style.display = 'block';
	document.getElementById('data').style.display = 'none';
	document.getElementById('TheBarCht').style.display='none';
	document.getElementById('copy').style.display = 'none';
	document.getElementById('trackgraphon').style.display = 'none';
	document.getElementById('trackgraphoff').style.display = 'none';
}

function hidegraphmode() 
{
	runstatus();
	document.getElementById('editon').style.display='block'; 
	document.getElementById('editoff').style.display='none';
	document.getElementById('grid').style.display='block'; 
	document.getElementById('graphic').style.display='none'; 
	document.getElementById('graphon').style.display = 'block';
	document.getElementById('graphoff').style.display = 'none';
	document.getElementById('graphed').style.display = 'none';
	document.getElementById('graphview').style.display='none';
	document.getElementById('data').style.display = 'block';
	document.getElementById('TheBarChtUpdt').style.display='none'; 
	document.getElementById('copy').style.display = 'none';
	document.getElementById('TheBarCht').style.display='none';
	document.getElementById('trackgraphon').style.display = 'none';
	document.getElementById('trackgraphoff').style.display = 'none';
	}

function runstatus(){

document.getElementById('status').innerHTML ='<img src="./images/status.gif">';

setTimeout("hidestatus()",600);	
}

function setstatus(){

document.getElementById('status').innerHTML ='<img src="./images/status.gif">';

setTimeout("hidestatus()",1000);	
}

function hidestatus()
{
document.getElementById("status").innerHTML = "";
}
/*
***	Process Request
***
*** This function performs an XMLHttpRequest to get new content
*/
function processRequest(input) 
{
	var search = input;
	var content = '';
	if (input != '')
	{
		var request = new XMLHttpRequest();
		request.open("GET", "http://www.jonbrown.org/foodcomp/searchtestd.php?id=" + encodeURIComponent(search) + "&onsearch=Search",false);
		request.send(null);
		content = request.responseText;
	}
	setstatus();
	document.getElementById('backbutton').style.display='none';
	document.getElementById('save').style.display='none';
	document.getElementById('save2').style.display='none';
	document.getElementById('searchresults').innerHTML = content;
	document.getElementById('graphon').style.display='none';
	document.getElementById('graphoff').style.display='none';
	document.getElementById('showfoods').style.display='none'; 
	document.getElementById('grid').style.display='none'; 
	document.getElementById('graphic').style.display='none'; 
	document.getElementById('graphview').style.display='none';
	document.getElementById('TheBarChtUpdt').style.display='none'; 
	document.getElementById('editon').style.display='none';
	document.getElementById('editoff').style.display='none';  
	document.getElementById('content').style.display = 'none';
	document.getElementById('welcome').style.display='none'; 
	document.getElementById('trackgraphon').style.display = 'none';
	document.getElementById('trackgraphoff').style.display = 'none';
	document.getElementById('TheBarCht').style.display='none';
	document.getElementById('searchfor').innerHTML = "Results for " + "&quot;" + 		document.getElementById('searchInput').value + "&quot;";
	document.getElementById('searchresults').style.top = '0px'; 
	calculateAndShowThumb(document.getElementById('searchresults'));
	


       	if (input == '')
	{
		document.getElementById('backbutton').style.display='none';
		document.getElementById('save').style.display='none';
		document.getElementById('save2').style.display='none';
		document.getElementById('status').style.display='none';
		document.getElementById('graphview').style.display='none';
		document.getElementById('content').style.display = 'block';
		document.getElementById('searchresults').style.display = 'none';
            	document.getElementById('welcome').style.display='block'; 
            	document.getElementById('searchfor').innerHTML =''; 
		document.getElementById('grid').style.display='none'; 
		document.getElementById('editon').style.display='none';
		document.getElementById('TheBarChtUpdt').style.display='none'; 
		document.getElementById('editoff').style.display='none';  
		document.getElementById('graphon').style.display='none';
		document.getElementById('graphoff').style.display='none';  
		document.getElementById('graphic').style.display='none'; 
		document.getElementById('trackgraphon').style.display = 'block';
		document.getElementById('TheBarCht').style.display='none';
		document.getElementById('trackgraphoff').style.display = 'none';
	}
        			
}


function loadData(input) 
{
	var search = input;
	var content = '';
	if (input != '')
	{
		var request = new XMLHttpRequest();
		request.open("GET", "http://www.jonbrown.org/foodcomp/nutritionfacts30d.php?id=" + encodeURIComponent(search),false);
		request.send(null);
		content = request.responseText;
	}
	document.getElementById('showfoods').innerHTML = content;
	
	runstatus();
	document.getElementById('backbutton').style.display='block';
	document.getElementById('save').style.display='block';
	document.getElementById('save2').style.display='block';
	document.getElementById('graph').style.display='block';
	document.getElementById('grid').style.display='block'; 
	document.getElementById('TheBarCht').style.display='none';
	document.getElementById('editon').style.display='block'; 
	document.getElementById('graphon').style.display='block';
	document.getElementById('graphview').style.display='none';
	document.getElementById('graphoff').style.display='none';
	document.getElementById('TheBarChtUpdt').style.display='none'; 
	document.getElementById('searchresults').style.display='none'; 
	document.getElementById('trackgraphon').style.display = 'none';
	document.getElementById('trackgraphoff').style.display = 'none';
	calculateAndShowThumb(document.getElementById('showfoods'));
}

function calcData(input) 
{
	var search = input;
	var content = '';
	if (input != '')
	{
		var request = new XMLHttpRequest();
		request.open("GET", "http://www.jonbrown.org/foodcomp/calculate30d.php?id=" + encodeURIComponent(search),false);
		request.send(null);
		content = request.responseText;
	}

	document.getElementById('showfoods').innerHTML = content;
	document.getElementById('backbutton').style.display='block';
	runstatus();
	document.getElementById('save').style.display='block';
	document.getElementById('save2').style.display='block';
	calculateAndShowThumb(document.getElementById('showfoods'));
        document.getElementById('grid').style.display='block'; 
	document.getElementById('editon').style.display='block'; 
	document.getElementById('TheBarCht').style.display='none';
	document.getElementById('graphview').style.display='none';
	document.getElementById('TheBarChtUpdt').style.display='none'; 
	document.getElementById('trackgraphon').style.display = 'none';
	document.getElementById('trackgraphoff').style.display = 'none';
	document.getElementById('searchresults').style.display='none'; 
}
function twocalcData(input) 
{
	var search = input;
	var content = '';
	if (input != '')
	{
		var request = new XMLHttpRequest();
		request.open("GET", "http://www.jonbrown.org/foodcomp/calculate230d.php?id=" + encodeURIComponent(search),false);
		request.send(null);
		content = request.responseText;
	}
	runstatus();
	document.getElementById('backbutton').style.display='block';
	document.getElementById('save').style.display='block';
	document.getElementById('save2').style.display='block';
	document.getElementById('showfoods').innerHTML = content;
	calculateAndShowThumb(document.getElementById('showfoods'));
        document.getElementById('grid').style.display='block'; 
	document.getElementById('TheBarCht').style.display='none';
	document.getElementById('graphview').style.display='none';
	document.getElementById('TheBarChtUpdt').style.display='none'; 
	document.getElementById('editon').style.display='block'; 
	document.getElementById('trackgraphon').style.display = 'none';
	document.getElementById('trackgraphoff').style.display = 'none';
	document.getElementById('searchresults').style.display='none'; 
}
function removeEvent(id) {
	saveList.splice(id, 1);
	buildList();
}
function buildList() {
	var content = document.getElementById("AddStuff");
	content.innerHTML = "";
	for(var i = 0; i < saveList.length; i++) {
		var div = document.createElement("div");
		div.setAttribute("id", "item"+i);
		var label = document.createElement("div");
		label.innerHTML = (i+1) + ".&nbsp;&nbsp;"+saveList[i].name+" <hr> <a href=\"javascript:;\" onclick=\"removeEvent(\'"+i+"\')\">Remove</a>";
		div.appendChild(label);
		var input = document.createElement("input");
		input.setAttribute("id","Calories"+i);
		input.setAttribute("value",saveList[i].calories);
		div.appendChild(input);
		
		var input = document.createElement('input');
		input.setAttribute("id","Total_Fats"+i);
		input.setAttribute("value",saveList[i].fats);
		div.appendChild(input);
		content.appendChild(div);
	}
}


/*function addEvent()
{
var FoodName = document.getElementById('editname').value;
var CalValue = document.getElementById('editcalories').value;
var FatValue = document.getElementById('editfats').value;

var ni = document.getElementById('AddStuff');
var numi = document.getElementById('theValue');
var num = (document.getElementById("theValue").value -1)+ 2;
numi.value = num;
var divIdName = "my"+num+"Div";
var divIdNameCals = "Calories"+num;
var divIdNameFats = "Total_Fats"+num;

var newdiv = document.createElement('div');
newdiv.setAttribute("id",divIdName);
newdiv.innerHTML = +num+".&nbsp;&nbsp;"+FoodName+" <hr> <a href=\"javascript:;\" onclick=\"removeEvent(\'"+divIdName+"\'),removeEvent(\'"+divIdNameFats+"\'),removeEvent(\'"+divIdNameCals+"\')\">Remove</a>";
ni.appendChild(newdiv);

var newdivcal = document.createElement('input');
newdivcal.setAttribute("id",divIdNameCals);
newdivcal.setAttribute("value",CalValue);
ni.appendChild(newdivcal);

var newdivfats = document.createElement('input');
newdivfats.setAttribute("id",divIdNameFats);
newdivfats.setAttribute("value",FatValue);
ni.appendChild(newdivfats);

}

function removeEvent(divNum)
{
var d = document.getElementById('AddStuff');
var olddiv = document.getElementById(divNum);
d.removeChild(olddiv);
}*/

function popupChanged(elem)
		
		{
			var hi = " Graph";
			
			var chosenOption = elem.value;
    			document.getElementById("selectname").innerText = chosenOption;
			document.getElementById("graphview").innerText = chosenOption;
			
}
function sortFunction(elem)
		
		{
		
			var chosenOption = elem.value;


		if (chosenOption == "Calories") {
		
		document.getElementById("Total_Fats1").style.display='none'
		document.getElementById("Total_Fats2").style.display='none'
		document.getElementById("Total_Fats3").style.display='none'
		document.getElementById("Total_Fats4").style.display='none'
		document.getElementById("Calories1").style.display='block'
		document.getElementById("Calories2").style.display='block'
		document.getElementById("Calories3").style.display='block'
		document.getElementById("Calories4").style.display='block'


	}
		if (chosenOption == "Total Fats") {
		
		document.getElementById("Calories1").style.display='none'
		document.getElementById("Calories2").style.display='none'
		document.getElementById("Calories3").style.display='none'
		document.getElementById("Calories4").style.display='none'
		document.getElementById("Total_Fats1").style.display='block'
		document.getElementById("Total_Fats2").style.display='block'
		document.getElementById("Total_Fats3").style.display='block'
		document.getElementById("Total_Fats4").style.display='block'

	}

}

function calTest()
{
var myArray = new Array("100", 2, 3.0);
var calories = myArray[0];
var fats = myArray[1];
document.getElementById('suming').value = calories;
calculateAndShowThumb(document.getElementById('AddStuff'));
}

function graphArray()
{
var graphingArray = new Array();
graphingArray.push("400");
var calgraphed = graphingArray.join(",");
document.getElementById('Arr').value = calgraphed;
}

