function BarChart(F) { var Bars, NBars, N, T, Bsh, St = "\n"
  var Min=1e308, Max=-Min, Sum=0
  var Bsw, Wid, Hgt, TopM = 25, BotM = 20 // Margins
  var BarCht = document.getElementById("TheBarCht")
  NBars = (Bars = F.Arr.value.split(/[^\w\.+-]+/)).length
  Wid = Math.round(parseInt(BarCht.style.width) / NBars)
  BarCht.style.width = Bsw = Wid*NBars + "px"
  Hgt = (Bsh = parseInt(BarCht.style.height)) - TopM - BotM
  for (N=0 ; N<NBars ; N++) { Sum += T = Bars[N] = +Bars[N]
    if (Max<T) Max = T ; if (Min>T) Min = T }
  Sum /= NBars
  document.getElementById("Average").innerHTML = StrS(Sum, 2, 3)

  if (isNaN(Sum)) { BarCht.innerHTML = "" ; return }

  function Scale(X) {
    return Hgt + TopM - Math.round(Hgt*(X-Min)/(Max-Min)) }

  for (N=0 ; N<NBars ; N++) { T = Scale(Bars[N])
    St += '<div style="position:absolute; background:url(images/BGgraph.png); border:1px solid #000; left:' +
      Wid*N + 'px; width:' + Wid + 'px; top:' + T + 'px; height:' +
      (Bsh-T) + 'px;"> ' + Bars[N] + '<\/div>\n' }

  St += '<div style="position:absolute; height:' + Scale(0) +
    'px; width:' + Bsw +
    '; left:0px; border-bottom: blue solid 1px;"></\div>\n'

  St += '<div style="position:absolute; height:' + Scale(Sum) +
    'px; width:' + Bsw +
    '; left:0px; border-bottom: red dashed 1px;"></\div>\n'

  BarCht.innerHTML = St }