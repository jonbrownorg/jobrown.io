var currentVersion; 

function checkversion() {  //called when the html document is loaded
    currentVersion = getKeyValue("Info.plist", "CFBundleVersion");
    checkForUpdate();
} 

function checkForUpdate() {
    req = new XMLHttpRequest();
    req.onreadystatechange = compareVersion;
    req.open("GET", "http://www.jonbrown.org/trackerversion.php", true);
    req.setRequestHeader("Cache-Control", "no-cache");
    req.send(null);
} 

function compareVersion() {
  if (req.readyState == 4) {
    if (req.status == 200) {
        var serverVersion = req.responseText; 

if ((currentVersion != serverVersion) &&
 (serverVersion != null) && (serverVersion != "")) {
document.getElementById('updateMessage').style.display='block';
        } else {
document.getElementById('updateMessage').style.display='none';
        }
    }
  }
}
function getKeyValue(plist, key) {
   var xml_http = new XMLHttpRequest();
   xml_http.open("GET", plist, false);
   xml_http.send(null); 

var xml = xml_http.responseXML;
var key_value = null;
var nodes = xml.getElementsByTagName("dict")[0].childNodes; 

   for (var i=0; i < nodes.length; i++) {
if (nodes[i].nodeType == 1 && nodes[i].tagName.toLowerCase()
== "key" && nodes[i].firstChild.data == key) {
         if (nodes[i+2].tagName.toLowerCase() != "array") {
            key_value = nodes[i+2].firstChild.data;
         } else {
            key_value = new Array();
            var ar_nodes = nodes[i+2].childNodes;
            for (var j=0; j < ar_nodes.length; j++) {
if (ar_nodes[j].nodeType == 1)
key_value.push(ar_nodes[j].firstChild.data);
            }
         } 

         break;
      }
   } 

   return key_value;
} 

function clickback_about() 
{
	if (about1.style.display == 'none') {
	document.getElementById('about1').style.display = 'block';
	document.getElementById('register1').style.display = 'none';
	document.getElementById('help1').style.display = 'none';
	document.getElementById('abouttext').style.display = 'block';
	document.getElementById('registertext').style.display = 'none';
	document.getElementById('helptext').style.display = 'none';
}
	else
{
	document.getElementById('about1').style.display = 'block';
}
}
function clickback_help() 
{
	if (help1.style.display == 'none') {
	document.getElementById('help1').style.display = 'block';
	document.getElementById('about1').style.display = 'none';
	document.getElementById('register1').style.display = 'none';
	document.getElementById('abouttext').style.display = 'none';
	document.getElementById('registertext').style.display = 'none';
	document.getElementById('helptext').style.display = 'block';
}
	else
{
	document.getElementById('help1').style.display = 'block';
}
}
function clickback_register() 
{
	if (register1.style.display == 'none') {
	document.getElementById('help1').style.display = 'none';
	document.getElementById('about1').style.display = 'none';
	document.getElementById('register1').style.display = 'block';
	document.getElementById('abouttext').style.display = 'none';
	document.getElementById('registertext').style.display = 'block';
	document.getElementById('helptext').style.display = 'none';
}
	else
{
	document.getElementById('register1').style.display = 'block';
}
}