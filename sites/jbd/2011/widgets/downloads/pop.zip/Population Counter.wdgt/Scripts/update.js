/*
***	Check for Update
***
*** This function is called when the widget is loaded
*/
function checkForUpdate() { 
    req = new XMLHttpRequest(); 
    req.onreadystatechange = compareVersion; 
    req.open("GET", "http://www.jonbrown.org/pop3.php", true); 
    req.setRequestHeader("Cache-Control", "no-cache"); 
    req.send(null); 
} 

function compareVersion() { 
  if (req.readyState == 4) { 
    if (req.status == 200) { 
        var serverVersion = req.responseText; 

        if ((currentVersion != serverVersion) && (serverVersion != null) && (serverVersion != "")) {

             document.getElementById('worldpop').style.display='none';	
             document.getElementById('updateMessage').style.display='block';	
        } else { 
             document.getElementById('updateMessage').style.display='none';
             document.getElementById('worldpop').style.display='display';
        } 
    } 
  } 
} 

function getKeyValue(plist, key) { 
   var xml_http = new XMLHttpRequest(); 
   xml_http.open("GET", plist, false); 
   xml_http.send(null); 
    
   var xml = xml_http.responseXML; 
   var key_value = null; 
   var nodes = xml.getElementsByTagName("dict")[0].childNodes; 

   for (var i=0; i < nodes.length; i++) { 
      if (nodes[i].nodeType == 1 && nodes[i].tagName.toLowerCase() == "key" && nodes[i].firstChild.data == key) { 
         if (nodes[i+2].tagName.toLowerCase() != "array") { 
            key_value = nodes[i+2].firstChild.data; 
         } else { 
            key_value = new Array(); 
            var ar_nodes = nodes[i+2].childNodes; 
            for (var j=0; j < ar_nodes.length; j++) { 
               if (ar_nodes[j].nodeType == 1) key_value.push(ar_nodes[j].firstChild.data); 
            } 
         } 
          
         break; 
      } 
   } 
    
   return key_value; 
} 

function loadedupdate() 
{
	currentVersion = getKeyValue("Info.plist", "CFBundleVersion"); 
    	checkForUpdate(); 
}

