//Copyright - 2005 - Jeremy Bilien - all rights reserved 

//  Search Code
var q = ""
var url = "http://www.maccast.com/index.php?s="
var a = "&submit=Search"
var space = "+"



function srch(q)
{

q = q.replace(/[\s]+/g,'+');

	if (q == "")
	{
		clearSearch()
	}
	else
	{
		if (widget)
			widget.openURL(url + q + a)
	}
}

